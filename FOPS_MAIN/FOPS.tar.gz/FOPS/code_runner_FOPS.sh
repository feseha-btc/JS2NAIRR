#!/bin/bash
# runner.sh
# Executes the complete four-step analysis pipeline for all FASTA files
# listed within the file provided as the first command-line argument ($1).
# --- Robustness Settings ---
# Exit immediately if a command exits with a non-zero status.
set -e
# Exit if any variable is used but not set.
set -u
# --- Configuration and Validation ---
# The input file containing the list of FASTA files is $1.
LIST_FILE_PATH="$1"
# Ensure the list file name was provided
if [ $# -ne 1 ]; then
    echo "Usage: $0 <path_to_file_list.txt>"
    echo "The list file must contain one FASTA file path per line."
    exit 1
fi
# Ensure the list file exists
if [ ! -f "$LIST_FILE_PATH" ]; then
    echo "Error: List file '$LIST_FILE_PATH' not found."
    exit 1
fi
# Read the list file into an array, skipping comments (#) and blank lines
FASTA_FILES=()
while IFS= read -r LINE; do
    # Remove leading/trailing whitespace
    TRIMMED_LINE=$(echo "$LINE" | xargs)
    
    # Skip empty lines or lines starting with '#'
    if [[ -z "$TRIMMED_LINE" || "$TRIMMED_LINE" =~ ^# ]]; then
        continue
    fi
    FASTA_FILES+=("$TRIMMED_LINE")
done < "$LIST_FILE_PATH"
NUM_FILES=${#FASTA_FILES[@]}
if [ $NUM_FILES -eq 0 ]; then
    echo "Error: List file '$LIST_FILE_PATH' contains no valid FASTA file paths."
    exit 1
fi
echo "--- Starting Batch Pipeline for $NUM_FILES Files listed in $LIST_FILE_PATH ---"
# Loop over all file paths read from the list file
for INPUT_FILE_PATH in "${FASTA_FILES[@]}"; do
    
    # 1. Validation and Setup
    if [ ! -f "$INPUT_FILE_PATH" ]; then
        echo "Warning: Input file '$INPUT_FILE_PATH' not found. Skipping."
        continue
    fi
    
    # Extract filename components
    INPUT_FILE_BASENAME=$(basename "$INPUT_FILE_PATH")
    PREFIX=$(basename "$INPUT_FILE_BASENAME" .fasta)
    # Create a unique working directory using the basename and timestamp
    WORKING_DIR="analysis_temp_${PREFIX}_$(date +%s)"
    
    echo ""
    echo "================================================================"
    echo "--- Processing File: $INPUT_FILE_BASENAME ---"
    
    # Create isolated working environment
    mkdir -p "$WORKING_DIR"
    
    # Copy input file to the isolated directory for local processing
    # Note: Copying is necessary because the subsequent scripts expect the file to be present locally.
    cp "$INPUT_FILE_PATH" "$WORKING_DIR/$INPUT_FILE_BASENAME"
    
    # Store current directory and switch to the working directory
    CURRENT_CWD=$(pwd)
    cd "$WORKING_DIR"
    # The Python scripts' paths are relative to the original script's location (one level up + scripts directory).
    SCRIPT_BASE="$CURRENT_CWD/../scripts"
    
    # --- Execution Steps (Inside isolated directory) ---
    # 1. Extract the longest sequence
    echo "1. Running Fops_get_longest_sequence.py..."
    python "$SCRIPT_BASE/Fops_get_longest_sequence.py" "$INPUT_FILE_BASENAME"
    
    # 2. Generate oligos from the master file
    echo "2. Running Fops_generate_oligo.py..."
    python "$SCRIPT_BASE/Fops_generate_oligo.py" "$INPUT_FILE_BASENAME"

    
    # 3. Cluster on GPU and capture time
    echo "3. Running Fops_geminiSimpleCluster_GPU.py (Timed)..."
    # Input files are the hardcoded intermediate names, which is safe inside this unique directory
#    time CUDA_VISIBLE_DEVICES=0 python "$SCRIPT_BASE/Fops_geminiSimpleCluster_GPU.py" \
    time python "$SCRIPT_BASE/Fops_geminiSimpleCluster_GPU.py" query_oligos.fasta master_oligos.fasta
       ###  python ../scripts/Fops_geminiSimpleCluster_GPU.py  query_oligos.fasta master_oligos.fasta

    # 4. Generate the final report
    echo "4. Running Fops_generate_report.py..."
    # The report will be generated in this directory with a timestamp.
    python "$SCRIPT_BASE/Fops_generate_report.py" query_oligos_GPU_results.csv "$INPUT_FILE_BASENAME"
    # 5 --- Post-Processing and Cleanup (Inside isolated directory) ---
    echo "5. Cleaning up intermediate files in $WORKING_DIR..."
    rm -f longest_seq.fasta master_oligos.fasta query_oligos.fasta query_oligos_GPU_results.csv "$INPUT_FILE_BASENAME"

    # 6. Inform user and return to original directory
    # Find the most recently created report file
    FINAL_REPORT_PATH=$(ls -t Final_Report_*.csv 2>/dev/null | head -n 1)
    
    if [ -n "$FINAL_REPORT_PATH" ]; then
        echo "--- Pipeline Finished Successfully for $INPUT_FILE_BASENAME ---"
        echo "Final report is located at: $CURRENT_CWD/$WORKING_DIR/$FINAL_REPORT_PATH"
    else
        echo "--- Pipeline Finished, but report not found for $INPUT_FILE_BASENAME. Check $WORKING_DIR for errors. ---"
    fi
    
    # Go back to the original directory
    cd "$CURRENT_CWD"
done
echo ""
echo "--- Batch Pipeline Complete ---"
