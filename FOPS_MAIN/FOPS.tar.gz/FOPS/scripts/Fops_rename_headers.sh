FASTA_FILE="$1"

awk -v fasta_file="$FASTA_FILE" '
    # Only process header lines
    /^>/ {
        old_name = substr($0, 2);  # Strip the initial > for the log file
        new_name = old_name;

        # The corrected substitution: replace the first space and everything after it with nothing.
        # This effectively keeps only the first "word" (the ID)

        sub(/ .*/, "", new_name); 

        # Log the changes: old_name <tab> new_name
        print old_name "\t" new_name >> (fasta_file "_rename_log.txt");

        # Update the header line with the new name and the >
        $0 = ">" new_name
    }
    # Print all lines (modified headers and unmodified sequences)
    1
' "$FASTA_FILE" > "${FASTA_FILE%.*}_renamed.${FASTA_FILE##*.}"
