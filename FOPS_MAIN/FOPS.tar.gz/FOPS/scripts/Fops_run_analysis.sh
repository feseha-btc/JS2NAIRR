#!/bin/bash
# --- Configuration ---
# Name of the file containing the list of FASTA files to process (one path per line).
FASTA_LIST_FILE="$1"
# Log file will be created with a timestamp.
LOG_FILE="analysis_pipeline_$(date +%Y%m%d_%H%M%S).log"
# --- Functions ---
# Function to safely run a command and log its status
run_command() {
    local cmd="$1"
    echo "[CMD] $cmd" >> "$LOG_FILE"
    eval "$cmd"
    if [ $? -ne 0 ]; then
        echo "[ERROR] Command failed: $cmd" >> "$LOG_FILE"
    fi
}
# --- Main Execution ---
if [ -z "$FASTA_LIST_FILE" ]; then
    echo "Usage: $0 <path_to_fasta_list_file>"
    echo "The list file should contain one FASTA file path per line."
    exit 1
fi
if [ ! -f "$FASTA_LIST_FILE" ]; then
    echo "Error: Input list file '$FASTA_LIST_FILE' not found."
    exit 1
fi
echo "Starting analysis pipeline. Results will be logged to: $LOG_FILE"
echo "--- Pipeline Start $(date) ---" > "$LOG_FILE"
echo "Processing files listed in: $FASTA_LIST_FILE" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"
# Loop through each FASTA file path in the input list
while IFS= read -r fasta_file; do
    # Skip empty or commented lines
    if [[ -z "$fasta_file" || "$fasta_file" =~ ^# ]]; then
        continue
    fi
    
    echo "=====================================================================" >> "$LOG_FILE"
    echo "STARTING ANALYSIS FOR: $fasta_file" >> "$LOG_FILE"
    
    # 0. Initial Cleanup: Ensure a fresh start for intermediate files
    echo "[PRE-CLEANUP] Clearing intermediate files..." >> "$LOG_FILE"
    rm -f longest_seq.fasta mastr_oligos.fasta query_oligos.fasta query_oligos_GPU_results.csv
    
    # 1. Extract the longest sequence (Script path: ../scripts/Fops_get_longest_sequence.py)
    # Output file: longest_seq.fasta (in CWD: data/)
    run_command "python ../scripts/Fops_get_longest_sequence.py \"$fasta_file\""
    
    # 2. Generate Oligos (Script path: ../scripts/Fops_generate_oligo.py)
    # The oligo script accepts the current FASTA file to process.
    # It reads longest_seq.fasta and creates mastr_oligos.fasta and query_oligos.fasta.
    run_command "python ../scripts/Fops_generate_oligo.py \"$fasta_file\""
    
    # 3. Cluster on GPU, capture time and verbose output (Script path: ../scripts/Fops_geminiSimpleCluster_GPU.py)
    echo "" >> "$LOG_FILE"
    echo "--- Fops_geminiSimpleCluster_GPU.py OUTPUT & TIME ---" >> "$LOG_FILE"
    
    # Execute the command group, piping all output (stdout and stderr from 'time') 
    # directly to the log file.
    { time python ../scripts/Fops_geminiSimpleCluster_GPU.py query_oligos.fasta mastr_oligos.fasta; } &>> "$LOG_FILE"
    
    echo "--- END Fops_geminiSimpleCluster_GPU.py OUTPUT & TIME ---" >> "$LOG_FILE"
    echo "" >> "$LOG_FILE"
    
    # 4. Generate the final report (Script path: ../scripts/Fops_generate_report.py)
    # CRITICAL FIX: Pass the current FASTA file as the second argument for sequence counting.
    run_command "python ../scripts/Fops_generate_report.py query_oligos_GPU_results.csv \"$fasta_file\""
    
    # 5. Clean up intermediate files
    echo "[POST-CLEANUP] Removing intermediate files..." >> "$LOG_FILE"
    rm -f longest_seq.fasta mastr_oligos.fasta query_oligos.fasta query_oligos_GPU_results.csv
    
    # 6. Pause
    echo "[PAUSE] Pausing for 30 seconds before next file..." >> "$LOG_FILE"
    sleep 30
    
    echo "FINISHED ANALYSIS FOR: $fasta_file" >> "$LOG_FILE"
    echo "=====================================================================" >> "$LOG_FILE"
    echo "" >> "$LOG_FILE"
done < "$FASTA_LIST_FILE"
echo "--- Pipeline Finished $(date) ---" >> "$LOG_FILE"
echo "All files processed. Check '$LOG_FILE' for details and timing information."
